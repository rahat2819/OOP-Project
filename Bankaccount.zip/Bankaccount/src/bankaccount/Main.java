
package bankaccount;


import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        

 Scanner input = new Scanner(System.in);
 System.out.println("Enter your UserName: ");
 String userName = input.nextLine();
 System.out.print("Enter your User ID: ");
 String userId = input.nextLine();
 System.out.print("Enter your Password: ");
 String password = input.nextLine();
 //input.nextLine();
 if(password.equals("12345"))
         {
            BankAccount obj = new BankAccount(userName,userId);
            obj.mainMenu();
         }
 else
    {
        System.out.println("Wrong Password! Try Again");
    }
  }
}
